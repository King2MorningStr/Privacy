
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import StringProperty
import os

import local_api  # side-effect: initializes Trinity
from upgrade_screens_mobile import (
    TierComparisonScreen,
    VectorStoreScreen,
    TradeManagerScreen,
    TradeOnboardingScreen,
    UpgradeLimitPromptScreen,
)

class HomeScreen(Screen):
    status_text = StringProperty("Initializing Trinity...")

    def on_enter(self):
        stats = local_api.get_system_stats()
        total_nodes = stats["memory"]["total_nodes"]
        total_concepts = stats["memory"]["total_concepts"]
        self.status_text = (
            f"Dimensional Cortex mobile online.\n"
            f"Nodes: {total_nodes} | Concepts: {total_concepts}"
        )

    def go_tier(self):
        if self.manager:
            self.manager.current = "tier_comparison"

    def go_vectors(self):
        if self.manager:
            self.manager.current = "vector_store"

    def go_trade(self):
        if self.manager:
            self.manager.current = "trade_manager"


class DimensionalCortexMobileApp(App):
    def build(self):
        kv_path = os.path.join(os.path.dirname(__file__), "dimensionalcortex.kv")
        with open(kv_path, "r", encoding="utf-8") as f:
            return Builder.load_string(f.read())


if __name__ == "__main__":
    DimensionalCortexMobileApp().run()
